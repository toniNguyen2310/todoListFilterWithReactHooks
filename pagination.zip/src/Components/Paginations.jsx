import React, { useEffect, useState } from "react";
import axios from "axios";
import CryptoList from "./com/CryptoList ";
import Pagination from "./com/Pagination ";

// import "./App.css";

const AppFake = () => {
  const [coinsData, setCoinsData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(8);

  useEffect(() => {
    const fetchApi = async () => {
      const response = await axios.get(
        "https://64c9473cb2980cec85c21b70.mockapi.io/infor"
      );
      console.log(response.data);
      setCoinsData(response.data);
    };
    fetchApi();
  }, []);
  const lastPostIndex = currentPage * postsPerPage;
  console.log("lastPostIndex>>> ", lastPostIndex);
  const firstPostIndex = lastPostIndex - postsPerPage;
  console.log("firstPostIndex>>> ", firstPostIndex);
  const currentPosts = coinsData.slice(firstPostIndex, lastPostIndex);
  console.log("currentPosts>>> ", currentPosts);
  return (
    <div className="app">
      <h1>Crypto Gallery</h1>
      <CryptoList coinsData={currentPosts} />
      <Pagination
        totalPosts={coinsData.length}
        postsPerPage={postsPerPage}
        setCurrentPage={setCurrentPage}
        currentPage={currentPage}
      />
    </div>
  );
};

export default AppFake;
