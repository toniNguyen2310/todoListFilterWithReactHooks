import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import PagiApi from "./PagiApi";

function App() {
  return (
    <>
      <PagiApi />
    </>
  );
}
export default App;
