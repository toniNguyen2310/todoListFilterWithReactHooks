import axios from "axios";
import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import ReactPaginate from "react-paginate";

function PagiApi(props) {
  const [loading, setLoading] = useState(false);
  const [listData, setListData] = useState();
  const [pageCount, setPageCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(5);

  const fetchApi = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        "https://64c9473cb2980cec85c21b70.mockapi.io/infor"
      );
      setListData(response.data);
      setPageCount(Math.ceil(response.data.length / itemsPerPage));
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };
  //   const pageCount = Math.ceil(listData.length / usersPerPage);
  useEffect(() => {
    fetchApi();
  }, []);
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const subset = listData?.slice(startIndex, endIndex);
  const handlePageClick = (data) => {
    setCurrentPage(data.selected);
  };
  return (
    <>
      {/* {listData &&
        listData.length > 0 &&
        listData.map((data) => {
          return (
            <div key={data.id}>
              <div>Name: {data.name}</div>
              <div>Age: {data.age}</div>
            </div>
          );
        })} */}
      {loading ? (
        <div>Loading....</div>
      ) : (
        <>
          {subset?.map((data) => {
            return (
              <div key={data.id}>
                <div>Name: {data.name}</div>
                <div>Age: {data.age}</div>
              </div>
            );
          })}
          <ReactPaginate
            nextLabel="next >"
            onPageChange={handlePageClick}
            pageRangeDisplayed={2}
            pageCount={pageCount}
            // forcePage={currentPage}
            previousLabel="< previous"
            pageClassName="page-item"
            pageLinkClassName="page-link"
            previousClassName="page-item"
            previousLinkClassName="page-link"
            nextClassName="page-item"
            nextLinkClassName="page-link"
            breakLabel="..."
            breakClassName="page-item"
            breakLinkClassName="page-link"
            containerClassName="pagination"
            activeClassName="active"
            renderOnZeroPageCount={null}
          />
        </>
      )}
    </>
  );
}

export default PagiApi;
